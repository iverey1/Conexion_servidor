<?php
include_once('conexion.php');
     $b= new Persona();

     $p=$_GET['id'];
    $res= $b->Buscar($p);

 while($fila=$res->fetch_assoc()){
      $array =$fila;
}
 echo json_encode($array);

?>