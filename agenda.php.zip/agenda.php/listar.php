<?php
include_once('conexion.php');
     $b= new Persona();
     $res= $b->Listar();

$persona = array(); //creamos un array

while($row=$res->fetch_assoc()) 
{ 
    $id=$row['id_persona'];
    $nombre=$row['nombre'];
    $correo=$row['correo'];
    $telefono=$row['telefono'];
  

    $persona[] = array('id_persona'=> $id, 'nombre'=> $nombre, 'correo'=> $correo,'telefono'=> $telefono);

}
    


//Creamos el JSON
$json_string = json_encode($persona);
echo $json_string;

?>