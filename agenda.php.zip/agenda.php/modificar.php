<?php 
    include_once('conexion.php');
     $mod= new Persona();
   //necesito el id del productoa a modificar
    echo $p=$_GET['id'];
    $res= $mod->Recupera($p);
    $fila=$res->fetch_assoc();

   ?>
 
<!DOCTYPE html>
<html>
<head>
</head>
<body>

       <form action="mod.php" method="post">
  	 <input type="hidden" name="id" value="<?php   echo $fila['id_persona'];?>">
   	 Nombre <input type="text" name="nombre" value="<?php   echo $fila['nombre'];?>"><br>
   	 Correo <input type="text" name="correo" value="<?php   echo $fila['correo'];?>"><br>
   	 Telefono <input type="text" name="telefono" value="<?php   echo $fila['telefono'];?>"><br>
   	 <input type="submit" value="Guardar" class="">
   </form>
      

   
</body>
</html>