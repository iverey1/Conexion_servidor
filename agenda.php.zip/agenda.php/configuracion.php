<?php 
  //Constantes de conexion a la base de datos
  define('HOST','localhost');//este localhost es sustituido por la direccion IP del servidor cuando
                              //la página esta el linea
  define('USER','root'); //Este usuario es sustituido por el nombre de usuario que se nos asigne 
                         //en un servidor
  define('PASS','');//contraseña de acceso
  define('DBNAME','agenda');//nombre de la base de datos

?>