
<?php 
include_once("conexion.php");
$objeto= new Persona();
       if($_SERVER['REQUEST_METHOD']== 'POST'){
           $n=$_POST['nombre'];
           $c=$_POST['correo'];
           $t=$_POST['telefono'];
          
       echo $num=$objeto->EvitarDuplicidad($n);
          if($num==0){
        $objeto->Alta($n,$c,$t);
        echo "perosna almacenada";
               }
              else
              	echo "persona ya registrada";}
   ?>
   
