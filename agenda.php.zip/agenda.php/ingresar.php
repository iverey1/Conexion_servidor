<?php 
    include_once('conexion.php');
   
   ?>
 
<!DOCTYPE html>
<html>
<head>
</head>
<body>

       <form action="persona.php" method="post">
  	 <input type="hidden" name="id"><br>
   	 Nombre <input type="text" name="nombre" ><br>
   	 Correo <input type="text" name="correo"><br>
   	 Telefono <input type="text" name="telefono" ><br>
   	 <input type="submit" value="Guardar">
   </form>
      

   
</body>
</html>