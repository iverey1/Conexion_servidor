<?php 
   include_once('conexion.php');
   $eli= new Persona();
   //necesito el id del productoa a eliminar
    $p=$_GET['id'];
    $eli->Eliminar($p);
  
?>