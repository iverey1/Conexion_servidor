<?php
include_once("configuracion.php");
 /**
  * 
  */
 class Persona {
     private $conn; 

     function __construct() {
       $this->conn=new mysqli(HOST,USER,PASS,DBNAME); 
       //inicializa la llave a la BD
 	}

 	public function Alta($n,$c,$t)
 	{
    $consulta="INSERT INTO persona(nombre,correo,telefono) VALUES ('".$n."','".$c."','".$t."')";
      if($this->conn->query($consulta))
      	echo "datos almacenados";
 	}
   public function Recupera($id){
       $consulta = "SELECT * FROM persona WHERE id_persona =".$id;
        $resultado=$this->conn->query($consulta);
        return $resultado;
   }
   public function Listar(){
   	  $consulta = "select * from persona";
   	  $resultado=$this->conn->query($consulta);
         return $resultado;
   }

   public function Modificar($id,$n,$c,$t){
     $consulta="UPDATE persona SET nombre='".$n."',correo='".$c."',telefono='".$t."'  WHERE id_persona=".$id;
      if($this->conn->query($consulta))
      	echo "datos modificados";
   }

   public function Eliminar($id){
   	 $consulta="DELETE FROM persona WHERE id_persona=".$id;
   	 if($this->conn->query($consulta))
      	echo "dato eliminado";
   }
  public function EvitarDuplicidad($n){
      	echo	$buscar="SELECT * FROM persona WHERE nombre like '%".$n."%'";
      		if($res=$this->conn->query($buscar)){
      		echo $norenglones = $res->num_rows;
                return $norenglones;} 
                  else return 0;
      	}
   
     public function Buscar($id){
               $consulta="SELECT * FROM persona WHERE id_persona=".$id;
   	$res=$this->conn->query($consulta);
                             return $res;
      }
     
 }
 ?>