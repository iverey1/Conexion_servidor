<?php 
include_once('conexion.php');
     $modi= new Persona();
     if($_SERVER['REQUEST_METHOD']== 'POST'){
           $id=$_POST['id'];
           $nom=$_POST['nombre'];
           $mail=$_POST['correo'];
           $tel=$_POST['telefono'];
           
        $modi->Modificar($id,$nom,$mail,$tel);
         }
   ?>
