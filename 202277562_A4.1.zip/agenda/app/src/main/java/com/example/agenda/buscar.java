package com.example.agenda;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class buscar extends AppCompatActivity implements View.OnClickListener {
    EditText edit1,edit2,edit3,edtid;
    Button b1,b4,b5;
    String id;
    RequestQueue requestQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar);
        edit1 = findViewById(R.id.edit5);
        edit2 = findViewById(R.id.edit6);
        edit3 = findViewById(R.id.edit7);
        edtid = findViewById(R.id.edtid);
        b1 = findViewById(R.id.bed);
        b4 = findViewById(R.id.belim);
        b5 = findViewById(R.id.bcerrar);
        requestQueue = Volley.newRequestQueue(this);
        Bundle extras = getIntent().getExtras();

        if (extras != null){
            id = extras.getString("id");
        }
        redUser();
        b1.setOnClickListener(this);
        b4.setOnClickListener(this);
    }

    private void redUser(){

        String URL = "http://192.168.8.2/agenda/buscar.php?id="+id;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                URL,
                null,
                new Response.Listener<JSONObject>(){
                    @Override
                    public void onResponse(JSONObject response){
                        String id_persona, nombre, correo, telefono;
                        try{
                            id_persona = response.getString("id_persona");
                            nombre = response.getString("nombre");
                            correo = response.getString("correo");
                            telefono = response.getString("telefono");
                            edtid.setText(id_persona);
                            edit1.setText(nombre);
                            edit2.setText(correo);
                            edit3.setText(telefono);
                        } catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){

                    }
                }
        );
        requestQueue.add(jsonObjectRequest);
    }
    @Override
    public void onClick(View v){
        int id = v.getId();

        if (id == R.id.bed){
            String nombre=edit1.getText().toString().trim();
            String correo=edit2.getText().toString().trim();
            String telefono=edit3.getText().toString().trim();
            updateUser(nombre,correo,telefono);
        }
        if(id == R.id.belim){
            String idUser = edtid.getText().toString().trim();
            removeUser(idUser);
        }
        if(id == R.id.bcerrar){
            finish();
        }
    }

    private void updateUser(String nombre, String correo,String telefono){
        String URL = "http://192.168.8.2/agenda/mod.php";
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                URL,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response){
                        Toast.makeText(buscar.this, "Dato modificado", Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        Toast.makeText(buscar.this, "Datos no almacenados", Toast.LENGTH_LONG).show();
                    }
                }
        ){
            @Override
            protected Map<String,String>getParams() throws AuthFailureError{
                Map<String,String> params = new HashMap<>();
                params.put("id",id);
                params.put("nombre",nombre);
                params.put("correo",correo);
                params.put("telefono",telefono);
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
    private void removeUser(String idUser){
        String URL = "http://192.168.8.2/agenda/eliminar.php" + idUser;
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                URL,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response){
                        Toast.makeText(buscar.this, "Dato Eliminado", Toast.LENGTH_LONG).show();
                        finish();
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError{
                Map<String, String> params = new HashMap<>();
                params.put("id",idUser);
                return params;
            }
        };
        requestQueue.add(stringRequest);
}

}