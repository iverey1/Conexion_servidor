package com.example.agenda;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public abstract class MainActivity extends AppCompatActivity implements View.OnClickListener {
EditText edit1, edit2,edit3, edit4;
Button b1,b2,b3;
    RequestQueue requestQueve;

private static final String URL1="http://192.168.8.2/agenda/persona.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit1=findViewById(R.id.edit1);
        edit2=findViewById(R.id.edit2);
        edit3=findViewById(R.id.edit3);
        edit4=findViewById(R.id.edit4);
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        requestQueve=Volley.newRequestQueue(this);

    }
    @Override
    public void onClick(View v) {

        int id=v.getId();
    if(id==R.id.b1) {
        String nombre = edit1.getText().toString().trim();
        String correo = edit2.getText().toString().trim();
        String telefono = edit3.getText().toString().trim();
        createUser(nombre, correo, telefono);

    }

if (id==R.id.b2) {
        Intent i = new Intent(this, buscar.class);
    i.putExtra("id", edit4.getText().toString().trim());
    startActivity(i);

}
    }
    private void createUser(final String nombre, final String correo, final String telefono) {
            StringRequest stringRequest=new StringRequest(
        Request.Method.POST,
        URL1,
        new Response.Listener<String>(){
            public void onResponse(String response){
        }
    },
    new Response.ErrorListener(){
        @Override
                public void onErrorResponse(VolleyError error){
            Toast.makeText(MainActivity.this, "error", Toast.LENGTH_LONG).show();

        }
    }

    ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("nombre", nombre);
                    params.put("correo", correo);
                    params.put("telefono", telefono);
                    return params;
                }
            };
        requestQueve.add(stringRequest);
    }
}